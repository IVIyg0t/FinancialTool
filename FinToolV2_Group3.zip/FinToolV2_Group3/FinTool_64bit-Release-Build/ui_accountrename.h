/********************************************************************************
** Form generated from reading UI file 'accountrename.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNTRENAME_H
#define UI_ACCOUNTRENAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_accountRename
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *accountRename)
    {
        if (accountRename->objectName().isEmpty())
            accountRename->setObjectName(QStringLiteral("accountRename"));
        accountRename->resize(238, 94);
        gridLayout = new QGridLayout(accountRename);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(accountRename);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 2);

        lineEdit = new QLineEdit(accountRename);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        gridLayout->addWidget(lineEdit, 1, 0, 1, 2);

        pushButton = new QPushButton(accountRename);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        gridLayout->addWidget(pushButton, 2, 0, 1, 1);

        pushButton_2 = new QPushButton(accountRename);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 2, 1, 1, 1);


        retranslateUi(accountRename);

        QMetaObject::connectSlotsByName(accountRename);
    } // setupUi

    void retranslateUi(QDialog *accountRename)
    {
        accountRename->setWindowTitle(QApplication::translate("accountRename", "Dialog", 0));
        label->setText(QApplication::translate("accountRename", "Type a new name for your current account", 0));
        pushButton->setText(QApplication::translate("accountRename", "Apply", 0));
        pushButton_2->setText(QApplication::translate("accountRename", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class accountRename: public Ui_accountRename {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNTRENAME_H
