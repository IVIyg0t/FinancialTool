/****************************************************************************
** Meta object code from reading C++ file 'fintool.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../FinToolV2-0/fintool.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fintool.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_FinTool_t {
    QByteArrayData data[16];
    char stringdata[343];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FinTool_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FinTool_t qt_meta_stringdata_FinTool = {
    {
QT_MOC_LITERAL(0, 0, 7), // "FinTool"
QT_MOC_LITERAL(1, 8, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 5), // "index"
QT_MOC_LITERAL(4, 43, 33), // "on_reports_addbankaccount_cli..."
QT_MOC_LITERAL(5, 77, 15), // "on_date_changed"
QT_MOC_LITERAL(6, 93, 25), // "on_actionRename_triggered"
QT_MOC_LITERAL(7, 119, 36), // "on_action_add_bank_account_tr..."
QT_MOC_LITERAL(8, 156, 35), // "on_action_add_transaction_tri..."
QT_MOC_LITERAL(9, 192, 35), // "on_actionAccount_Deletion_tri..."
QT_MOC_LITERAL(10, 228, 27), // "on_menuBank_Account_hovered"
QT_MOC_LITERAL(11, 256, 8), // "QAction*"
QT_MOC_LITERAL(12, 265, 20), // "on_cell_date_changed"
QT_MOC_LITERAL(13, 286, 20), // "on_cell_item_changed"
QT_MOC_LITERAL(14, 307, 26), // "on_cell_item_doubleclicked"
QT_MOC_LITERAL(15, 334, 8) // "cellMenu"

    },
    "FinTool\0on_tabWidget_currentChanged\0"
    "\0index\0on_reports_addbankaccount_clicked\0"
    "on_date_changed\0on_actionRename_triggered\0"
    "on_action_add_bank_account_triggered\0"
    "on_action_add_transaction_triggered\0"
    "on_actionAccount_Deletion_triggered\0"
    "on_menuBank_Account_hovered\0QAction*\0"
    "on_cell_date_changed\0on_cell_item_changed\0"
    "on_cell_item_doubleclicked\0cellMenu"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FinTool[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   74,    2, 0x08 /* Private */,
       4,    0,   77,    2, 0x08 /* Private */,
       5,    0,   78,    2, 0x08 /* Private */,
       6,    0,   79,    2, 0x08 /* Private */,
       7,    0,   80,    2, 0x0a /* Public */,
       8,    0,   81,    2, 0x0a /* Public */,
       9,    0,   82,    2, 0x0a /* Public */,
      10,    1,   83,    2, 0x0a /* Public */,
      12,    0,   86,    2, 0x0a /* Public */,
      13,    2,   87,    2, 0x0a /* Public */,
      14,    2,   92,    2, 0x0a /* Public */,
      15,    1,   97,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QPoint,    2,

       0        // eod
};

void FinTool::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FinTool *_t = static_cast<FinTool *>(_o);
        switch (_id) {
        case 0: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_reports_addbankaccount_clicked(); break;
        case 2: _t->on_date_changed(); break;
        case 3: _t->on_actionRename_triggered(); break;
        case 4: _t->on_action_add_bank_account_triggered(); break;
        case 5: _t->on_action_add_transaction_triggered(); break;
        case 6: _t->on_actionAccount_Deletion_triggered(); break;
        case 7: _t->on_menuBank_Account_hovered((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 8: _t->on_cell_date_changed(); break;
        case 9: _t->on_cell_item_changed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: _t->on_cell_item_doubleclicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->cellMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    }
}

const QMetaObject FinTool::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_FinTool.data,
      qt_meta_data_FinTool,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FinTool::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FinTool::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FinTool.stringdata))
        return static_cast<void*>(const_cast< FinTool*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int FinTool::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
