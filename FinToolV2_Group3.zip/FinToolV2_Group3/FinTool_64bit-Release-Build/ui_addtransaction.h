/********************************************************************************
** Form generated from reading UI file 'addtransaction.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDTRANSACTION_H
#define UI_ADDTRANSACTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>

QT_BEGIN_NAMESPACE

class Ui_addTransaction
{
public:
    QSplitter *splitter_10;
    QSplitter *splitter_9;
    QSplitter *splitter_4;
    QLabel *label;
    QDateEdit *date;
    QSplitter *splitter_6;
    QSplitter *splitter_3;
    QLabel *label_2;
    QComboBox *Category;
    QSplitter *splitter_5;
    QLabel *label_3;
    QComboBox *TransactionType;
    QSplitter *splitter_8;
    QSplitter *splitter_2;
    QLabel *label_4;
    QDoubleSpinBox *Amount;
    QSplitter *splitter;
    QLabel *label_5;
    QLineEdit *addInfo;
    QSplitter *splitter_7;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *addTransaction)
    {
        if (addTransaction->objectName().isEmpty())
            addTransaction->setObjectName(QStringLiteral("addTransaction"));
        addTransaction->resize(361, 248);
        splitter_10 = new QSplitter(addTransaction);
        splitter_10->setObjectName(QStringLiteral("splitter_10"));
        splitter_10->setGeometry(QRect(9, 9, 341, 231));
        splitter_10->setOrientation(Qt::Vertical);
        splitter_9 = new QSplitter(splitter_10);
        splitter_9->setObjectName(QStringLiteral("splitter_9"));
        splitter_9->setOrientation(Qt::Horizontal);
        splitter_4 = new QSplitter(splitter_9);
        splitter_4->setObjectName(QStringLiteral("splitter_4"));
        splitter_4->setOrientation(Qt::Vertical);
        label = new QLabel(splitter_4);
        label->setObjectName(QStringLiteral("label"));
        splitter_4->addWidget(label);
        date = new QDateEdit(splitter_4);
        date->setObjectName(QStringLiteral("date"));
        date->setCalendarPopup(true);
        splitter_4->addWidget(date);
        splitter_9->addWidget(splitter_4);
        splitter_10->addWidget(splitter_9);
        splitter_6 = new QSplitter(splitter_10);
        splitter_6->setObjectName(QStringLiteral("splitter_6"));
        splitter_6->setOrientation(Qt::Horizontal);
        splitter_3 = new QSplitter(splitter_6);
        splitter_3->setObjectName(QStringLiteral("splitter_3"));
        splitter_3->setOrientation(Qt::Vertical);
        label_2 = new QLabel(splitter_3);
        label_2->setObjectName(QStringLiteral("label_2"));
        splitter_3->addWidget(label_2);
        Category = new QComboBox(splitter_3);
        Category->setObjectName(QStringLiteral("Category"));
        splitter_3->addWidget(Category);
        splitter_6->addWidget(splitter_3);
        splitter_5 = new QSplitter(splitter_6);
        splitter_5->setObjectName(QStringLiteral("splitter_5"));
        splitter_5->setOrientation(Qt::Vertical);
        label_3 = new QLabel(splitter_5);
        label_3->setObjectName(QStringLiteral("label_3"));
        splitter_5->addWidget(label_3);
        TransactionType = new QComboBox(splitter_5);
        TransactionType->setObjectName(QStringLiteral("TransactionType"));
        splitter_5->addWidget(TransactionType);
        splitter_6->addWidget(splitter_5);
        splitter_10->addWidget(splitter_6);
        splitter_8 = new QSplitter(splitter_10);
        splitter_8->setObjectName(QStringLiteral("splitter_8"));
        splitter_8->setOrientation(Qt::Horizontal);
        splitter_2 = new QSplitter(splitter_8);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setOrientation(Qt::Vertical);
        label_4 = new QLabel(splitter_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        splitter_2->addWidget(label_4);
        Amount = new QDoubleSpinBox(splitter_2);
        Amount->setObjectName(QStringLiteral("Amount"));
        Amount->setMaximum(10000);
        Amount->setValue(0);
        splitter_2->addWidget(Amount);
        splitter_8->addWidget(splitter_2);
        splitter_10->addWidget(splitter_8);
        splitter = new QSplitter(splitter_10);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Vertical);
        label_5 = new QLabel(splitter);
        label_5->setObjectName(QStringLiteral("label_5"));
        splitter->addWidget(label_5);
        addInfo = new QLineEdit(splitter);
        addInfo->setObjectName(QStringLiteral("addInfo"));
        splitter->addWidget(addInfo);
        splitter_10->addWidget(splitter);
        splitter_7 = new QSplitter(splitter_10);
        splitter_7->setObjectName(QStringLiteral("splitter_7"));
        splitter_7->setOrientation(Qt::Horizontal);
        pushButton = new QPushButton(splitter_7);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        splitter_7->addWidget(pushButton);
        pushButton_2 = new QPushButton(splitter_7);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        splitter_7->addWidget(pushButton_2);
        splitter_10->addWidget(splitter_7);

        retranslateUi(addTransaction);

        QMetaObject::connectSlotsByName(addTransaction);
    } // setupUi

    void retranslateUi(QDialog *addTransaction)
    {
        addTransaction->setWindowTitle(QApplication::translate("addTransaction", "Dialog", 0));
        label->setText(QApplication::translate("addTransaction", "Date", 0));
        label_2->setText(QApplication::translate("addTransaction", "Category", 0));
        label_3->setText(QApplication::translate("addTransaction", "Transaction Type", 0));
        label_4->setText(QApplication::translate("addTransaction", "Amount", 0));
        label_5->setText(QApplication::translate("addTransaction", "Additional Information", 0));
        pushButton->setText(QApplication::translate("addTransaction", "OK", 0));
        pushButton_2->setText(QApplication::translate("addTransaction", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class addTransaction: public Ui_addTransaction {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDTRANSACTION_H
