/********************************************************************************
** Form generated from reading UI file 'account_delete.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNT_DELETE_H
#define UI_ACCOUNT_DELETE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_account_delete
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QSplitter *splitter;
    QSplitter *splitter_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *account_delete)
    {
        if (account_delete->objectName().isEmpty())
            account_delete->setObjectName(QStringLiteral("account_delete"));
        account_delete->resize(225, 89);
        gridLayout = new QGridLayout(account_delete);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        splitter = new QSplitter(account_delete);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Vertical);
        splitter_2 = new QSplitter(splitter);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setOrientation(Qt::Vertical);
        label = new QLabel(splitter_2);
        label->setObjectName(QStringLiteral("label"));
        splitter_2->addWidget(label);
        lineEdit = new QLineEdit(splitter_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        splitter_2->addWidget(lineEdit);
        splitter->addWidget(splitter_2);

        verticalLayout->addWidget(splitter);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton = new QPushButton(account_delete);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(account_delete);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);


        retranslateUi(account_delete);

        QMetaObject::connectSlotsByName(account_delete);
    } // setupUi

    void retranslateUi(QDialog *account_delete)
    {
        account_delete->setWindowTitle(QApplication::translate("account_delete", "Dialog", 0));
        label->setText(QApplication::translate("account_delete", "Name the account that you wish to delete:", 0));
        pushButton->setText(QApplication::translate("account_delete", "Ok", 0));
        pushButton_2->setText(QApplication::translate("account_delete", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class account_delete: public Ui_account_delete {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNT_DELETE_H
