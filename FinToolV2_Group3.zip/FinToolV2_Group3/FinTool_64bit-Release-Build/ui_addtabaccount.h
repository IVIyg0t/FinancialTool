/********************************************************************************
** Form generated from reading UI file 'addtabaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDTABACCOUNT_H
#define UI_ADDTABACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>

QT_BEGIN_NAMESPACE

class Ui_addTabAccount
{
public:
    QSplitter *splitter_5;
    QSplitter *splitter_4;
    QSplitter *splitter_2;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QSplitter *splitter_3;
    QLabel *label;
    QComboBox *comboBox;
    QSplitter *splitter;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *addTabAccount)
    {
        if (addTabAccount->objectName().isEmpty())
            addTabAccount->setObjectName(QStringLiteral("addTabAccount"));
        addTabAccount->resize(228, 89);
        splitter_5 = new QSplitter(addTabAccount);
        splitter_5->setObjectName(QStringLiteral("splitter_5"));
        splitter_5->setGeometry(QRect(9, 9, 211, 71));
        splitter_5->setOrientation(Qt::Vertical);
        splitter_4 = new QSplitter(splitter_5);
        splitter_4->setObjectName(QStringLiteral("splitter_4"));
        splitter_4->setOrientation(Qt::Horizontal);
        splitter_2 = new QSplitter(splitter_4);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setOrientation(Qt::Vertical);
        label_2 = new QLabel(splitter_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        splitter_2->addWidget(label_2);
        lineEdit = new QLineEdit(splitter_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        splitter_2->addWidget(lineEdit);
        splitter_4->addWidget(splitter_2);
        splitter_3 = new QSplitter(splitter_4);
        splitter_3->setObjectName(QStringLiteral("splitter_3"));
        splitter_3->setOrientation(Qt::Vertical);
        label = new QLabel(splitter_3);
        label->setObjectName(QStringLiteral("label"));
        splitter_3->addWidget(label);
        comboBox = new QComboBox(splitter_3);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        splitter_3->addWidget(comboBox);
        splitter_4->addWidget(splitter_3);
        splitter_5->addWidget(splitter_4);
        splitter = new QSplitter(splitter_5);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        pushButton = new QPushButton(splitter);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        splitter->addWidget(pushButton);
        pushButton_2 = new QPushButton(splitter);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        splitter->addWidget(pushButton_2);
        splitter_5->addWidget(splitter);

        retranslateUi(addTabAccount);

        QMetaObject::connectSlotsByName(addTabAccount);
    } // setupUi

    void retranslateUi(QDialog *addTabAccount)
    {
        addTabAccount->setWindowTitle(QApplication::translate("addTabAccount", "Dialog", 0));
        label_2->setText(QApplication::translate("addTabAccount", "Account Name", 0));
        label->setText(QApplication::translate("addTabAccount", "Account Type", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("addTabAccount", "Checking", 0)
         << QApplication::translate("addTabAccount", "Savings", 0)
         << QApplication::translate("addTabAccount", "CD", 0)
        );
        pushButton->setText(QApplication::translate("addTabAccount", "OK", 0));
        pushButton_2->setText(QApplication::translate("addTabAccount", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class addTabAccount: public Ui_addTabAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDTABACCOUNT_H
