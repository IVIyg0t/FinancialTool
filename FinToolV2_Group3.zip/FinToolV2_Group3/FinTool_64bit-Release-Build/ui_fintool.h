/********************************************************************************
** Form generated from reading UI file 'fintool.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINTOOL_H
#define UI_FINTOOL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FinTool
{
public:
    QAction *actionNew_transaction;
    QAction *actionNew_bank_account;
    QAction *actionDelete;
    QAction *actionRename;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QGridLayout *gridLayout_4;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *label_8;
    QPushButton *reports_addbankaccount;
    QWidget *page_2;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QLabel *label_3;
    QDateEdit *irfromdate;
    QLabel *label_5;
    QDateEdit *irtodate;
    QLabel *label_2;
    QDateEdit *srfromdate;
    QLabel *label_6;
    QDateEdit *srtodate;
    QLabel *label_4;
    QDateEdit *safromdate;
    QLabel *label_7;
    QDateEdit *satodate;
    QTableWidget *incomereport;
    QTableWidget *balancereport;
    QTableWidget *spendinganalysis;
    QTableWidget *spendingreport;
    QMenuBar *menuBar;
    QMenu *menuAdd;
    QMenu *menuSettings;
    QMenu *menuBank_Account;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *FinTool)
    {
        if (FinTool->objectName().isEmpty())
            FinTool->setObjectName(QStringLiteral("FinTool"));
        FinTool->resize(1074, 673);
        actionNew_transaction = new QAction(FinTool);
        actionNew_transaction->setObjectName(QStringLiteral("actionNew_transaction"));
        actionNew_bank_account = new QAction(FinTool);
        actionNew_bank_account->setObjectName(QStringLiteral("actionNew_bank_account"));
        actionDelete = new QAction(FinTool);
        actionDelete->setObjectName(QStringLiteral("actionDelete"));
        actionRename = new QAction(FinTool);
        actionRename->setObjectName(QStringLiteral("actionRename"));
        centralWidget = new QWidget(FinTool);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setTabBarAutoHide(false);
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayout_4 = new QGridLayout(tab_2);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        stackedWidget = new QStackedWidget(tab_2);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        label_8 = new QLabel(page);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(40, 10, 741, 411));
        label_8->setTextFormat(Qt::AutoText);
        label_8->setAlignment(Qt::AlignCenter);
        reports_addbankaccount = new QPushButton(page);
        reports_addbankaccount->setObjectName(QStringLiteral("reports_addbankaccount"));
        reports_addbankaccount->setGeometry(QRect(320, 270, 161, 51));
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        gridLayout_2 = new QGridLayout(page_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        label = new QLabel(page_2);
        label->setObjectName(QStringLiteral("label"));

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        label_3 = new QLabel(page_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_2->addWidget(label_3, 0, 4, 1, 1);

        irfromdate = new QDateEdit(page_2);
        irfromdate->setObjectName(QStringLiteral("irfromdate"));

        gridLayout_2->addWidget(irfromdate, 0, 5, 1, 1);

        label_5 = new QLabel(page_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(label_5, 0, 6, 1, 1);

        irtodate = new QDateEdit(page_2);
        irtodate->setObjectName(QStringLiteral("irtodate"));

        gridLayout_2->addWidget(irtodate, 0, 7, 1, 1);

        label_2 = new QLabel(page_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_2->addWidget(label_2, 2, 0, 1, 1);

        srfromdate = new QDateEdit(page_2);
        srfromdate->setObjectName(QStringLiteral("srfromdate"));

        gridLayout_2->addWidget(srfromdate, 2, 1, 1, 1);

        label_6 = new QLabel(page_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        sizePolicy.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(label_6, 2, 2, 1, 1);

        srtodate = new QDateEdit(page_2);
        srtodate->setObjectName(QStringLiteral("srtodate"));

        gridLayout_2->addWidget(srtodate, 2, 3, 1, 1);

        label_4 = new QLabel(page_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_2->addWidget(label_4, 2, 4, 1, 1);

        safromdate = new QDateEdit(page_2);
        safromdate->setObjectName(QStringLiteral("safromdate"));

        gridLayout_2->addWidget(safromdate, 2, 5, 1, 1);

        label_7 = new QLabel(page_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_2->addWidget(label_7, 2, 6, 1, 1);

        satodate = new QDateEdit(page_2);
        satodate->setObjectName(QStringLiteral("satodate"));

        gridLayout_2->addWidget(satodate, 2, 7, 1, 1);

        incomereport = new QTableWidget(page_2);
        incomereport->setObjectName(QStringLiteral("incomereport"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(incomereport->sizePolicy().hasHeightForWidth());
        incomereport->setSizePolicy(sizePolicy1);
        incomereport->setEditTriggers(QAbstractItemView::NoEditTriggers);
        incomereport->horizontalHeader()->setStretchLastSection(true);

        gridLayout_2->addWidget(incomereport, 1, 4, 1, 4);

        balancereport = new QTableWidget(page_2);
        balancereport->setObjectName(QStringLiteral("balancereport"));
        sizePolicy1.setHeightForWidth(balancereport->sizePolicy().hasHeightForWidth());
        balancereport->setSizePolicy(sizePolicy1);
        balancereport->setEditTriggers(QAbstractItemView::NoEditTriggers);
        balancereport->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        balancereport->horizontalHeader()->setStretchLastSection(true);

        gridLayout_2->addWidget(balancereport, 1, 0, 1, 4);

        spendinganalysis = new QTableWidget(page_2);
        spendinganalysis->setObjectName(QStringLiteral("spendinganalysis"));
        sizePolicy1.setHeightForWidth(spendinganalysis->sizePolicy().hasHeightForWidth());
        spendinganalysis->setSizePolicy(sizePolicy1);
        spendinganalysis->setEditTriggers(QAbstractItemView::NoEditTriggers);
        spendinganalysis->horizontalHeader()->setStretchLastSection(true);

        gridLayout_2->addWidget(spendinganalysis, 3, 4, 1, 4);

        spendingreport = new QTableWidget(page_2);
        spendingreport->setObjectName(QStringLiteral("spendingreport"));
        sizePolicy1.setHeightForWidth(spendingreport->sizePolicy().hasHeightForWidth());
        spendingreport->setSizePolicy(sizePolicy1);
        spendingreport->setEditTriggers(QAbstractItemView::NoEditTriggers);
        spendingreport->horizontalHeader()->setStretchLastSection(true);

        gridLayout_2->addWidget(spendingreport, 3, 0, 1, 4);

        stackedWidget->addWidget(page_2);

        gridLayout_4->addWidget(stackedWidget, 0, 1, 1, 1);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 0, 0, 1, 1);

        FinTool->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(FinTool);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1074, 20));
        menuAdd = new QMenu(menuBar);
        menuAdd->setObjectName(QStringLiteral("menuAdd"));
        menuSettings = new QMenu(menuBar);
        menuSettings->setObjectName(QStringLiteral("menuSettings"));
        menuBank_Account = new QMenu(menuSettings);
        menuBank_Account->setObjectName(QStringLiteral("menuBank_Account"));
        FinTool->setMenuBar(menuBar);
        statusBar = new QStatusBar(FinTool);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        FinTool->setStatusBar(statusBar);

        menuBar->addAction(menuSettings->menuAction());
        menuBar->addAction(menuAdd->menuAction());
        menuAdd->addAction(actionNew_transaction);
        menuAdd->addAction(actionNew_bank_account);
        menuSettings->addAction(menuBank_Account->menuAction());
        menuBank_Account->addAction(actionDelete);
        menuBank_Account->addAction(actionRename);

        retranslateUi(FinTool);

        tabWidget->setCurrentIndex(0);
        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(FinTool);
    } // setupUi

    void retranslateUi(QMainWindow *FinTool)
    {
        FinTool->setWindowTitle(QApplication::translate("FinTool", "FinTool", 0));
        actionNew_transaction->setText(QApplication::translate("FinTool", "New transaction", 0));
        actionNew_bank_account->setText(QApplication::translate("FinTool", "New bank account", 0));
        actionDelete->setText(QApplication::translate("FinTool", "Delete", 0));
        actionRename->setText(QApplication::translate("FinTool", "Rename", 0));
        label_8->setText(QApplication::translate("FinTool", "There are no bank accounts to create reports from", 0));
        reports_addbankaccount->setText(QApplication::translate("FinTool", "Add a bank account", 0));
        label->setText(QApplication::translate("FinTool", "Balance Report", 0));
        label_3->setText(QApplication::translate("FinTool", "Income Report", 0));
        label_5->setText(QApplication::translate("FinTool", "to", 0));
        label_2->setText(QApplication::translate("FinTool", "Spending Report", 0));
        label_6->setText(QApplication::translate("FinTool", "to", 0));
        label_4->setText(QApplication::translate("FinTool", "Spending Analysis", 0));
        label_7->setText(QApplication::translate("FinTool", "to", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("FinTool", "Reports", 0));
        menuAdd->setTitle(QApplication::translate("FinTool", "Add", 0));
        menuSettings->setTitle(QApplication::translate("FinTool", "Settings", 0));
        menuBank_Account->setTitle(QApplication::translate("FinTool", "Bank Account", 0));
    } // retranslateUi

};

namespace Ui {
    class FinTool: public Ui_FinTool {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINTOOL_H
