/********************************************************************************
** Form generated from reading UI file 'createfirsttabaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEFIRSTTABACCOUNT_H
#define UI_CREATEFIRSTTABACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_createFirstTabAccount
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QComboBox *comboBox;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *createFirstTabAccount)
    {
        if (createFirstTabAccount->objectName().isEmpty())
            createFirstTabAccount->setObjectName(QStringLiteral("createFirstTabAccount"));
        createFirstTabAccount->resize(258, 96);
        gridLayout = new QGridLayout(createFirstTabAccount);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(createFirstTabAccount);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(createFirstTabAccount);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 0, 1, 1, 1);

        lineEdit = new QLineEdit(createFirstTabAccount);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        gridLayout->addWidget(lineEdit, 1, 0, 1, 1);

        comboBox = new QComboBox(createFirstTabAccount);
        comboBox->setObjectName(QStringLiteral("comboBox"));

        gridLayout->addWidget(comboBox, 1, 1, 1, 1);

        buttonBox = new QDialogButtonBox(createFirstTabAccount);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 2, 0, 1, 2);


        retranslateUi(createFirstTabAccount);
        QObject::connect(buttonBox, SIGNAL(accepted()), createFirstTabAccount, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), createFirstTabAccount, SLOT(reject()));

        QMetaObject::connectSlotsByName(createFirstTabAccount);
    } // setupUi

    void retranslateUi(QDialog *createFirstTabAccount)
    {
        createFirstTabAccount->setWindowTitle(QApplication::translate("createFirstTabAccount", "Dialog", 0));
        label->setText(QApplication::translate("createFirstTabAccount", "Bank Account name", 0));
        label_2->setText(QApplication::translate("createFirstTabAccount", "Account Type", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("createFirstTabAccount", "Checking", 0)
         << QApplication::translate("createFirstTabAccount", "Savings", 0)
         << QApplication::translate("createFirstTabAccount", "CD", 0)
        );
    } // retranslateUi

};

namespace Ui {
    class createFirstTabAccount: public Ui_createFirstTabAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEFIRSTTABACCOUNT_H
