/********************************************************************************
** Form generated from reading UI file 'createaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEACCOUNT_H
#define UI_CREATEACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_createAccount
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *username;
    QLabel *label_2;
    QLineEdit *password;
    QPushButton *createaccount;
    QPushButton *cancel;

    void setupUi(QDialog *createAccount)
    {
        if (createAccount->objectName().isEmpty())
            createAccount->setObjectName(QStringLiteral("createAccount"));
        createAccount->resize(132, 160);
        gridLayout = new QGridLayout(createAccount);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(createAccount);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        username = new QLineEdit(createAccount);
        username->setObjectName(QStringLiteral("username"));

        gridLayout->addWidget(username, 1, 0, 1, 1);

        label_2 = new QLabel(createAccount);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        password = new QLineEdit(createAccount);
        password->setObjectName(QStringLiteral("password"));

        gridLayout->addWidget(password, 3, 0, 1, 1);

        createaccount = new QPushButton(createAccount);
        createaccount->setObjectName(QStringLiteral("createaccount"));

        gridLayout->addWidget(createaccount, 4, 0, 1, 1);

        cancel = new QPushButton(createAccount);
        cancel->setObjectName(QStringLiteral("cancel"));

        gridLayout->addWidget(cancel, 5, 0, 1, 1);


        retranslateUi(createAccount);

        QMetaObject::connectSlotsByName(createAccount);
    } // setupUi

    void retranslateUi(QDialog *createAccount)
    {
        createAccount->setWindowTitle(QApplication::translate("createAccount", "Dialog", 0));
        label->setText(QApplication::translate("createAccount", "Username:", 0));
        label_2->setText(QApplication::translate("createAccount", "Password", 0));
        createaccount->setText(QApplication::translate("createAccount", "Create Account", 0));
        cancel->setText(QApplication::translate("createAccount", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class createAccount: public Ui_createAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEACCOUNT_H
