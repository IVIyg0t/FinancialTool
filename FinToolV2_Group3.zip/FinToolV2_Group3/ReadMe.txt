Built using Qt V5.4.1

Qt Project files and source code is located in FinToolV2-0

The release build (should be standalone exe) is located in FinTool_64bit-Release-Build/release/FinToolV2-0.exe

Please email me at robertsmj3@vcu.edu or any of the other members if you have issues running it.  There is a
chance that if your not running on windows 8.1 the standalone exe may error because of a missing .dll.  Let
us know and we can probably get it for you if it's a Qt specific file. 